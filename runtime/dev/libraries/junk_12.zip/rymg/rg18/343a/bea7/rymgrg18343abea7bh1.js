var me = this; 
var ME = $('#'+me.UUID)[0];

me.ready = function(){
  send_chuckme_too(function(result){
    var el = $(ME).find('div');
    el.text(JSON.stringify(result));
  });
};
