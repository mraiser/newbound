let system = DataStore::globals().get_object("system");
let events = system.get_object("timers");
println!("{}",events.to_string());
events