$(document).ready(function( event, ui ) {
  activateControls(document);
});

