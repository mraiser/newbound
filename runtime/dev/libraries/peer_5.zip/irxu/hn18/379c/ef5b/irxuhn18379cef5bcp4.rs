  START.call_once(|| { P2PCONS.set(RwLock::new(HashMap::new())); });
  do_listen(ipaddr, port)
}

static START: Once = Once::new();
static P2PCONS:Storage<RwLock<HashMap<i64, P2PConnection>>> = Storage::new();

#[derive(Debug)]
pub struct RelayStream {
  from: String,
  to: String,
  buf: DataArray,
  data: DataObject,
}

impl RelayStream {
  pub fn new(from:String, to:String) -> RelayStream {
    let mut o = DataObject::new();
    o.put_i64("last_contact", time());
    RelayStream{
      from:from,
      to:to,
      buf:DataArray::new(),
      data:o,
    }
  }
  
  pub fn duplicate(&self) -> RelayStream {
    RelayStream{
      from:self.from.to_owned(),
      to:self.to.to_owned(),
      buf:self.buf.duplicate(),
      data:self.data.duplicate(),
    }
  }
  
  pub fn last_contact(&self) -> i64 {
    self.data.get_i64("last_contact")
  }
}

#[derive(Debug)]
pub enum P2PStream {
  Tcp(TcpStream),
  Relay(RelayStream),
  Udp(UdpStream),
}

impl P2PStream {
  pub fn is_tcp(&self) -> bool {
    match self {
      P2PStream::Tcp(_stream) => true,
      P2PStream::Relay(_stream) => false,
      P2PStream::Udp(_stream) => false,
    }
  }
  
  pub fn is_udp(&self) -> bool {
    match self {
      P2PStream::Tcp(_stream) => false,
      P2PStream::Relay(_stream) => false,
      P2PStream::Udp(_stream) => true,
    }
  }
  
  pub fn is_relay(&self) -> bool {
    match self {
      P2PStream::Tcp(_stream) => false,
      P2PStream::Relay(_stream) => true,
      P2PStream::Udp(_stream) => false,
    }
  }

  pub fn mode(&self) -> String {
    match self {
      P2PStream::Tcp(_stream) => {
        "TCP".to_string()
      },
      P2PStream::Relay(_stream) => {
        "RELAY".to_string()
      },
      P2PStream::Udp(_stream) => {
        "UDP".to_string()
      },
    }
  }
  
  pub fn try_clone(&self) -> io::Result<P2PStream> {
    match self {
      P2PStream::Tcp(stream) => {
        let s2 = stream.try_clone()?;
        Ok(P2PStream::Tcp(s2))
      },
      P2PStream::Relay(stream) => {
        Ok(P2PStream::Relay(stream.duplicate()))
      },
      P2PStream::Udp(stream) => {
        Ok(P2PStream::Udp(stream.duplicate()))
      },
    }
  }
  
  pub fn write(&mut self, buf: &[u8]) -> io::Result<usize> {
    match self {
      P2PStream::Tcp(stream) => {
        stream.write(buf)
      },
      P2PStream::Relay(stream) => {
        let from = &stream.from;
        let to = &stream.to;
        
        let user = get_user(&from);
        if user.is_some(){
          let user = user.unwrap();
          let con = get_tcp(user);
          if con.is_some(){
            let con = con.unwrap();
            let cipher = con.cipher;
            let mut stream = con.stream;
            let mut bytes = ("fwd ".to_string()+&to).as_bytes().to_vec();
            bytes.extend_from_slice(buf);

            let buf = encrypt(&cipher, &bytes);
            let len = buf.len() as i16;
            let mut bytes = len.to_be_bytes().to_vec();
            bytes.extend_from_slice(&buf);
            let x = stream.write(&bytes)?;
            return Ok(x);
          }
          panic!("No route to relay {}", from);
        }
        panic!("No such relay {}", from);
      },
      P2PStream::Udp(stream) => {
        stream.write(buf)
      },
    }
  }
  
  pub fn read_exact(&mut self, buf: &mut [u8]) -> io::Result<()> {
    match self {
      P2PStream::Tcp(stream) => {
        stream.read_exact(buf)
      },
      P2PStream::Relay(stream) => {
        let len = buf.len();
        let mut i = 0;
        let mut v = Vec::new();
        while i < len {
          let mut timeout = 0;
          let beat = Duration::from_millis(100);
          while stream.buf.len() == 0 {
            // TIGHTLOOP
            thread::sleep(beat);
            timeout += 1;
            if timeout > 1000 { println!("Unusually long wait in peer:service:listen:p2p_stream:relay:read_exact [{}]", stream.data.get_i64("id")); timeout = 0; }
          }
          
          let bd = &mut stream.buf.get_bytes(0);
          let bytes = bd.get_data();
          let n = std::cmp::min(bytes.len(), len-i);
          v.extend_from_slice(&bytes[0..n]);
          let bytes = bytes[n..].to_vec();
          if bytes.len() > 0 { bd.set_data(&bytes); }
          else { stream.buf.remove_property(0); }
          i += n;
        }        
        buf.clone_from_slice(&v);
        Ok(())
      },
      P2PStream::Udp(stream) => {
        stream.read_exact(buf)
      },
    }
  }
  
  pub fn peer_addr(&self) -> io::Result<SocketAddr> {
    match self {
      P2PStream::Tcp(stream) => {
        stream.peer_addr()
      },
      P2PStream::Relay(_stream) => {
        panic!("Not implemented");
      },
      P2PStream::Udp(stream) => {
        Ok(stream.src)
      },
    }
  }
  
  pub fn describe(&self) -> String {
    match self {
      P2PStream::Tcp(stream) => {
        let x = stream.peer_addr();
        if x.is_err() { return "CLOSED".to_string(); }
        x.unwrap().to_string()
      },
      P2PStream::Relay(stream) => {
        format!("via {} to {}", stream.from, stream.to)
      },
      P2PStream::Udp(stream) => {
        stream.src.to_string()
      },
    }
  }
  
  pub fn shutdown(&self) -> io::Result<()> {
    match self {
      P2PStream::Tcp(stream) => {
        stream.shutdown(Shutdown::Both)
      },
      P2PStream::Relay(_stream) => {
        Ok(())
      },
      P2PStream::Udp(stream) => {
        stream.duplicate().data.put_bool("dead", true);
        Ok(())
      },
    }
  }
  
  pub fn peek(&self, buf: &mut [u8]) -> io::Result<usize> {
    match self {
      P2PStream::Tcp(stream) => {
        stream.peek(buf)
      },
      P2PStream::Relay(_stream) => {
        panic!("Not implemented");
      },
      P2PStream::Udp(_stream) => {
        panic!("Not implemented");
      },
    }
  }
  
  pub fn last_contact(&self) -> i64 {
    match self {
      P2PStream::Tcp(_stream) => { 
        // FIXME
        time()
      },
      P2PStream::Relay(stream) => {
        stream.last_contact()
      },
      P2PStream::Udp(stream) => {
        stream.last_contact()
      },
    }
  }
}

#[derive(Debug)]
pub struct P2PConnection {
  pub stream: P2PStream,
  pub sessionid: String,
  pub cipher: Aes256,
  pub uuid: String,
  pub res: DataObject,
  pub pending: DataArray,
  pub x: bool,
}

impl P2PConnection {
  pub fn get(conid:i64) -> P2PConnection {
    P2PCONS.get().write().unwrap().get(&conid).unwrap().duplicate()
  }
  
  pub fn try_get(conid:i64) -> Option<P2PConnection> {
    let x = P2PCONS.get().write().unwrap().get(&conid)?.duplicate();
    Some(x)
  }
  
  pub fn list() -> Vec<i64> {
    let mut v = Vec::new();
    for i in P2PCONS.get().write().unwrap().keys() {
      v.push(*i);
    }
    v
  }
  
  pub fn duplicate(&self) -> P2PConnection {
    P2PConnection{
      stream: self.stream.try_clone().unwrap(),
      sessionid: self.sessionid.to_owned(),
      cipher: self.cipher.to_owned(),
      uuid: self.uuid.to_owned(),
      res: self.res.duplicate(),
      pending: self.pending.duplicate(),
      x: self.x,
    }
  }
    
  pub fn begin(uuid:String, stream:P2PStream) -> (i64, P2PConnection) {
    let user = get_user(&uuid).unwrap();
    let mut cons = user.get_array("connections");
    
    // FIXME - move cipher generation to its own function
    let system = DataStore::globals().get_object("system");
    let runtime = system.get_object("apps").get_object("app").get_object("runtime");
    let my_private = runtime.get_string("privatekey");
    let my_private = decode_hex(&my_private).unwrap();
    let my_private: [u8; 32] = my_private.try_into().expect("slice with incorrect length");
    let my_private = StaticSecret::from(my_private);
    
    let peer_public = user.get_string("publickey");
    let peer_public = decode_hex(&peer_public).unwrap();
    let peer_public: [u8; 32] = peer_public.try_into().expect("slice with incorrect length");
    let peer_public = PublicKey::from(peer_public);
    let shared_secret = my_private.diffie_hellman(&peer_public);
    let key = GenericArray::from(shared_secret.to_bytes());
    let cipher = Aes256::new(&key);
    
    let sessionid = unique_session_id();
    let con = P2PConnection{
      stream: stream,
      sessionid: sessionid.to_owned(),
      cipher: cipher,
      uuid: uuid.to_string(),
      res: DataObject::new(),
      pending: DataArray::new(),
      x: true,
    };
    
    let sessiontimeoutmillis = system.get_object("config").get_i64("sessiontimeoutmillis");

    // FIXME - Make session creation its own thing
    let mut session = DataObject::new();
    session.put_i64("count", 0);
    session.put_str("id", &sessionid);
    session.put_str("username", &uuid);
    session.put_object("user", user.duplicate());
    let expire = time() + sessiontimeoutmillis;
    session.put_i64("expire", expire);

    let mut sessions = system.get_object("sessions");
    sessions.put_object(&sessionid, session.duplicate());
    
    let conid;
    {
      let mut heap = P2PCONS.get().write().unwrap();
      loop {
        let x = rand::thread_rng().gen::<i64>();
        if !heap.contains_key(&x) {
          conid = x;
          heap.insert(conid, con.duplicate());
          cons.push_i64(conid);
          break;
        }
      }
    }
    
    fire_event("peer", "UPDATE", user_to_peer(user.duplicate(), uuid.to_string()));
    fire_event("peer", "CONNECT", user_to_peer(user.duplicate(), uuid.to_string()));
    println!("P2P {} Connect {} / {} / {} / {}", con.stream.mode(), con.stream.describe(), sessionid, user.get_string("displayname"), uuid);

    (conid, con)
  }
  
  pub fn shutdown(&self, uuid:&str, conid:i64) -> io::Result<()> {
    let user = get_user(uuid).unwrap();
    user.get_array("connections").remove_data(Data::DInt(conid));
    let mut con;
    {
      let mut heap = P2PCONS.get().write().unwrap();
      let x = heap.get(&conid);
      if x.is_none() { return Ok(()); }
      con = x.unwrap().duplicate();
      heap.remove(&conid);
    }
    let x = self.stream.shutdown();
    fire_event("peer", "UPDATE", user_to_peer(user.duplicate(), uuid.to_string()));
    fire_event("peer", "DISCONNECT", user_to_peer(user.duplicate(), uuid.to_string()));
    
    let mut o = DataObject::new();
    o.put_str("status", "err");
    o.put_str("msg", "Connection closed");
    for pid in con.pending.objects() {
      let pid = pid.int();
      con.res.put_object(&pid.to_string(), o.duplicate());
    }
    
    if self.stream.is_tcp(){
      let users = DataStore::globals().get_object("system").get_object("users");
      for (uuid2,_u) in users.objects() {
        if uuid2.len() == 36 && uuid != uuid2 {
          relay(&uuid, &uuid2, false);
        }
      }
    }
    
    let mut sessions = DataStore::globals().get_object("system").get_object("sessions");
    sessions.remove_property(&con.sessionid);
    
    println!("P2P {} Disconnect {} / {} / {} / {}", con.stream.mode(), con.stream.describe(), self.sessionid, user.get_string("displayname"), uuid);
    x
  }
  
  pub fn last_contact(&self) -> i64 {
    self.stream.last_contact()
  }
}

pub fn get_best(user:DataObject) -> Option<P2PConnection> {
  let mut best = None;
  let heap = P2PCONS.get().write().unwrap();
  let cons = user.get_array("connections");
//  println!("heap {:?} cons {}", heap, cons.to_string());
  for con in cons.objects(){
    let conid = con.int();
    let con = heap.get(&conid).unwrap();
    if con.stream.is_tcp() {
      return Some(con.duplicate());
    }
    else if (&best).is_none() { best = Some(con.duplicate()); }
    else if (&best).as_ref().unwrap().stream.is_relay() && con.stream.is_udp() { best = Some(con.duplicate()); }
  }
  best
}

pub fn get_tcp(user:DataObject) -> Option<P2PConnection> {
  let heap = P2PCONS.get().write().unwrap();
  let cons = user.get_array("connections");
//  println!("heap {:?} cons {}", heap, cons.to_string());
  for con in cons.objects(){
    let conid = con.int();
    let con = heap.get(&conid).unwrap();
    if con.stream.is_tcp() {
      return Some(con.duplicate());
    }
  }
  None
}

pub fn get_udp(user:DataObject) -> Option<P2PConnection> {
  let heap = P2PCONS.get().write().unwrap();
  let cons = user.get_array("connections");
//  println!("heap {:?} cons {}", heap, cons.to_string());
  for con in cons.objects(){
    let conid = con.int();
    let con = heap.get(&conid).unwrap();
    if con.stream.is_udp() {
      return Some(con.duplicate());
    }
  }
  None
}

pub fn get_relay(user:DataObject) -> Option<P2PConnection> {
  let heap = P2PCONS.get().write().unwrap();
  let cons = user.get_array("connections");
//  println!("heap {:?} cons {}", heap, cons.to_string());
  for con in cons.objects(){
    let conid = con.int();
    let con = heap.get(&conid).unwrap();
    if con.stream.is_relay() {
      return Some(con.duplicate());
    }
  }
  None
}

pub fn relay(from:&str, to:&str, connected:bool) -> Option<P2PConnection>{
  let user = get_user(to).unwrap();
  let cons = user.get_array("connections");
  for con in cons.objects(){
    let conid = con.int();
    let con = P2PConnection::get(conid);
    if let P2PStream::Relay(stream) = &con.stream {
      if stream.from == from && stream.to == to {
        if connected { return Some(con.duplicate()); }
        let _x = con.shutdown(to, conid as i64);
      }
    }
  }
  if connected {
    let stream = RelayStream::new(from.to_string(), to.to_string());
    let stream = P2PStream::Relay(stream);
    let (_conid, con) = P2PConnection::begin(to.to_string(), stream);
    return Some(con.duplicate());
  }
  None
}

pub fn handshake(stream: &mut P2PStream, peer: Option<String>) -> Option<(i64, P2PConnection)> {
  let system = DataStore::globals().get_object("system");
  let runtime = system.get_object("apps").get_object("app").get_object("runtime");
  let my_uuid = runtime.get_string("uuid");

  // FIXME - move cipher generation to its own function
  let my_public = runtime.get_string("publickey");
  let my_private = runtime.get_string("privatekey");
  let my_private = decode_hex(&my_private).unwrap();
  let my_private: [u8; 32] = my_private.try_into().expect("slice with incorrect length");
  let my_private = StaticSecret::from(my_private);

  // Temp key pair for initial exchange
  let my_session_private = StaticSecret::new(OsRng);
  let my_session_public = PublicKey::from(&my_session_private);

  // Send temp pubkey if init
  let init = peer.is_some();
  if init { let _x = stream.write(&my_session_public.to_bytes()).unwrap(); }

  // Read remote temp pubkey
  let mut bytes = vec![0u8; 32];
  let _x = stream.read_exact(&mut bytes).unwrap();
  let remote_session_public: [u8; 32] = bytes.try_into().expect("slice with incorrect length");
  let remote_session_public = PublicKey::from(remote_session_public);

  // Send temp pubkey if not init
  if !init { let _x = stream.write(&my_session_public.to_bytes()).unwrap(); }
  
  // Temp cipher for initial exchange
  let shared_secret = my_session_private.diffie_hellman(&remote_session_public);
  let key = GenericArray::from(shared_secret.to_bytes());
  let cipher = Aes256::new(&key);

  // Send my UUID
  let bytes = encrypt(&cipher, my_uuid.as_bytes());
  let _x = stream.write(&bytes).unwrap();

  // Get remote UUID
  let mut bytes = vec![0u8; 48];
  let _x = stream.read_exact(&mut bytes).unwrap();
  let mut bytes = decrypt(&cipher, &bytes);
  bytes.resize(36, 0);
  let uuid = String::from_utf8(bytes).unwrap();
  if init && peer.unwrap().to_owned() != uuid { return None; }
  
  let user = get_user(&uuid);
  if user.is_some(){
    let mut user = user.unwrap();
    let havekey = user.has("publickey");

    // Send my_step: 0 = sendpubkey, 1 = continue
    let my_step;
    if havekey { my_step = 1; } else { my_step = 0; }
    let _x = stream.write(&[my_step]).unwrap();

    //read remote_step
    let mut bytes = vec![0u8; 1];
    let x = stream.read_exact(&mut bytes);
    if x.is_err() { return None; }
    
    let remote_step = bytes[0];

    // Remote step
    if remote_step == 0 {
      let bytes = encrypt(&cipher, &decode_hex(&my_public).unwrap());
      let _x = stream.write(&bytes).unwrap();
    }
    else if remote_step != 1 {
      return None;
    }
    
    // mystep
    let peer_public_string;
    let mut saveme = false;
    if !havekey {
      let mut bytes = vec![0u8; 32];
      let _x = stream.read_exact(&mut bytes).unwrap();
      peer_public_string = to_hex(&decrypt(&cipher, &bytes));
      saveme = true;
    }
    else { peer_public_string = user.get_string("publickey"); }
    
    let peer_public = decode_hex(&peer_public_string).unwrap();
    let peer_public: [u8; 32] = peer_public.try_into().expect("slice with incorrect length");
    let peer_public = PublicKey::from(peer_public);
    let shared_secret = my_private.diffie_hellman(&peer_public);
    let key = GenericArray::from(shared_secret.to_bytes());
    let cipher = Aes256::new(&key);

    let isok;
    if init {
      let mut bytes = vec![0u8; 16];
      let _x = stream.read_exact(&mut bytes).unwrap();
      let mut bytes = decrypt(&cipher, &bytes);
      bytes.resize(16, 0);
      let sig = String::from_utf8(bytes).unwrap();
      if sig != "What's good, yo?" { isok = false; }
      else {
        let buf = encrypt(&cipher, "All is good now!".as_bytes());
        let _x = stream.write(&buf).unwrap();
        isok = true;
      }
    }
    else {
      let buf = encrypt(&cipher, "What's good, yo?".as_bytes());
      let _x = stream.write(&buf).unwrap();

      let mut bytes = vec![0u8; 16];
      let _x = stream.read_exact(&mut bytes).unwrap();
      let mut bytes = decrypt(&cipher, &bytes);
      bytes.resize(16, 0);
      let sig = String::from_utf8(bytes).unwrap();

      isok = sig == "All is good now!" 
    }
    
    if isok {
      let (conid, con) = P2PConnection::begin(uuid.to_owned(), stream.try_clone().unwrap());
  
      if saveme {
        user.put_str("publickey", &peer_public_string);
        set_user(&uuid, user.duplicate());
      }
      
      return Some((conid, con));
    }
  }
  None
}

fn do_listen(ipaddr:String, port:i64) -> i64 {
  let socket_address = ipaddr+":"+&port.to_string();
  let listener = TcpListener::bind(socket_address).unwrap();
  
  let system = DataStore::globals().get_object("system");
  let mut botd = system.get_object("apps").get_object("peer").get_object("runtime");
  let b = port == 0;
  let port = listener.local_addr().unwrap().port();
  botd.put_i64("port", port as i64);
  
  if b {
    let file = DataStore::new().root
                .parent().unwrap()
                .join("runtime")
                .join("peer")
                .join("botd.properties");
  	let _x = write_properties(file.into_os_string().into_string().unwrap(), botd);
  }

  println!("P2P TCP listening on port {}", port);

  // FIXME - Interrupt and quit if !system.running
  for stream in listener.incoming() {
    let stream = stream.unwrap();
    thread::spawn(move || {
      let remote_addr = stream.peer_addr().unwrap();
      println!("P2P TCP incoming request from {}", remote_addr);
      
      let mut stream = P2PStream::Tcp(stream);
      
      let con = handshake(&mut stream, None);
      if con.is_some() {
        let (conid, con) = con.unwrap();
        handle_connection(conid, con);
      }
    });
  }
  port.into()
}

pub fn handle_connection(conid:i64, con:P2PConnection) {
  // loop
  let system = DataStore::globals().get_object("system");
  while system.get_bool("running") {
    if !handle_next_message(con.duplicate()) { break; }
  }
  // end loop
  
  let _x = con.shutdown(&con.uuid, conid);
}

pub fn handle_next_message(con:P2PConnection) -> bool {
  let mut stream = con.stream;
  let cipher = con.cipher;
  let uuid = con.uuid;
  let mut res = con.res;
  let system = DataStore::globals().get_object("system");
  let sessions = system.get_object("sessions");
  let sessionid = con.sessionid;
  let mut session = sessions.get_object(&sessionid);
  
  let mut bytes = vec![0u8; 2];
  let x = stream.read_exact(&mut bytes);
  if x.is_err() { 
    return false; 
  }

  let bytes: [u8; 2] = bytes.try_into().unwrap();
  let len = i16::from_be_bytes(bytes) as usize; // FIXME - Should be u16
  let mut bytes:Vec<u8> = Vec::with_capacity(len);
  bytes.resize(len, 0);
  let _x = stream.read_exact(&mut bytes).unwrap();
  let bytes = decrypt(&cipher, &bytes);
  let method = String::from_utf8(bytes[0..4].to_vec()).unwrap();

  let sessiontimeoutmillis = system.get_object("config").get_i64("sessiontimeoutmillis");
  session.put_i64("expire", time() + sessiontimeoutmillis);
  let count = session.get_i64("count") + 1;
  session.put_i64("count", count);

  if method == "rcv " {
    let uuid2 = std::str::from_utf8(&bytes[4..40]).unwrap();
    let buf = &bytes[40..];
    
    let bytes: [u8; 2] = buf[0..2].try_into().unwrap();
    let len2 = i16::from_be_bytes(bytes) as usize;
    let mut buf = buf.to_vec();
    buf.resize(len2+2,0);
    
    let con = relay(&uuid, &uuid2, true).unwrap();  
	if let P2PStream::Relay(mut stream) = con.stream.try_clone().unwrap() {
      stream.buf.push_bytes(DataBytes::from_bytes(&buf.to_vec()));
      stream.data.put_i64("last_contact", time());
      handle_next_message(con);
    }
  }
  else if method == "fwd ".to_string() {
    let uuid2 = std::str::from_utf8(&bytes[4..40]).unwrap();
    let buf = &bytes[40..];

    let con = get_tcp(get_user(&uuid2).unwrap());
    if con.is_some() {
      let con = con.unwrap();
      let cipher = con.cipher;
      let mut stream = con.stream;

      let mut bytes = ("rcv ".to_string()+&uuid).as_bytes().to_vec();
      bytes.extend_from_slice(buf);

      let buf = encrypt(&cipher, &bytes);
      let len = buf.len() as i16;
      let mut bytes = len.to_be_bytes().to_vec();
      bytes.extend_from_slice(&buf);
      let _x = stream.write(&bytes).unwrap();
    }
    else {
      let s = "err fwd ".to_string() + &uuid2;
      let mut bytes = s.as_bytes().to_vec();
      let len = buf.len() as i16;
      bytes.extend_from_slice(&len.to_be_bytes());
      bytes.extend_from_slice(&buf);
      
      let buf = encrypt(&cipher, &bytes);
      let len = buf.len() as i16;
      let mut bytes = len.to_be_bytes().to_vec();
      bytes.extend_from_slice(&buf);
      let _x = stream.write(&bytes).unwrap();
    }
  }
  else if method == "err ".to_string() {
    let cmd = String::from_utf8(bytes[4..8].to_vec()).unwrap();
    if cmd == "fwd " {
      let uuid2 = String::from_utf8(bytes[8..44].to_vec()).unwrap();
      let uuid2 = uuid2.trim_matches(char::from(0));
      
      // FIXME - Ignored, don't send
      //let buf: [u8; 2] = bytes[44..46].try_into().unwrap();
      //let len2 = i16::from_be_bytes(buf) as usize; 
      let bytes = &bytes[46..];
      let buf: [u8; 2] = bytes[..2].try_into().unwrap();
      let len3 = i16::from_be_bytes(buf) as usize;
      let buf = &bytes[2..];
      let buf = &buf[..len3];

      let user = get_user(uuid2).unwrap();
      
      // FIXME - move cipher generation to its own function
      let system = DataStore::globals().get_object("system");
      let runtime = system.get_object("apps").get_object("app").get_object("runtime");
      let my_private = runtime.get_string("privatekey");
      let my_private = decode_hex(&my_private).unwrap();
      let my_private: [u8; 32] = my_private.try_into().expect("slice with incorrect length");
      let my_private = StaticSecret::from(my_private);

      let peer_public = user.get_string("publickey");
      let peer_public = decode_hex(&peer_public).unwrap();
      let peer_public: [u8; 32] = peer_public.try_into().expect("slice with incorrect length");
      let peer_public = PublicKey::from(peer_public);
      let shared_secret = my_private.diffie_hellman(&peer_public);
      let key = GenericArray::from(shared_secret.to_bytes());
      let cipher = Aes256::new(&key);
      
      let bytes = decrypt(&cipher, &buf);
      let s = String::from_utf8(bytes).unwrap();
      let s = s.trim_matches(char::from(0));
      let o = DataObject::from_string(&s[4..]);
      let pid = o.get_i64("pid");
      let pid = &pid.to_string();
      let mut con = relay(&uuid, &uuid2, true).unwrap();
      
      let mut err = DataObject::new();
      err.put_str("status", "err");
      err.put_str("msg", "No route to host");
      con.res.put_object(&pid, err);
      
//      println!("SUSPECT 2 {} -> {}", uuid,uuid2);
      relay(&uuid, &uuid2, false);
    }
  }
  else if method == "cmd ".to_string() {
    let msg = String::from_utf8(bytes[4..].to_vec()).unwrap();
    let msg = msg.trim_matches(char::from(0));
    let d = DataObject::from_string(msg);
    let mut params = d.get_object("params");
    params.put_str("nn_sessionid", &sessionid);
    params.put_object("nn_session", session.duplicate());

    let mut stream = stream.try_clone().unwrap();
    let cipher = cipher.to_owned();
    let sessionid = sessionid.to_owned();
    thread::spawn(move || {
      let o = handle_command(d, sessionid);

      let s = "res ".to_string() + &o.to_string();
      let buf = encrypt(&cipher, s.as_bytes());
      let len = buf.len() as i16;

      //        let _lock = P2PHEAP.get().write().unwrap();
      let mut bytes = len.to_be_bytes().to_vec();
      bytes.extend_from_slice(&buf);
      let _x = stream.write(&bytes).unwrap();
    });
  }
  else if method == "res ".to_string() {
    let msg = String::from_utf8(bytes[4..].to_vec()).unwrap();
    let msg = msg.trim_matches(char::from(0));
    let d = DataObject::from_string(msg);
    let i = d.get_i64("pid");
    res.put_object(&i.to_string(), d);
  }
  else {
    println!("Unknown message type: {}", method);
  }
  true
}

pub fn encrypt(cipher:&Aes256, buf:&[u8]) -> Vec<u8> {
  let mut buf = buf.to_vec();
  while buf.len() % 16 != 0 { buf.push(0); }
  let blocks: Vec<&[u8]> = buf.chunks(16).collect();
  let mut buf = Vec::new();
  for ba in blocks {
    let block: [u8; 16] = ba.try_into().expect("slice with incorrect length");
    let mut block = GenericArray::from(block);
    cipher.encrypt_block(&mut block);
    buf.extend_from_slice(&block[0..16]);
  }
  buf
}

pub fn decrypt(cipher:&Aes256, buf:&[u8]) -> Vec<u8> {
  let mut buf = buf.to_vec();
  while buf.len() % 16 != 0 { buf.push(0); }
  let blocks: Vec<&[u8]> = buf.chunks(16).collect();
  let mut buf = Vec::new();
  for ba in blocks {
    let block: [u8; 16] = ba.try_into().expect("slice with incorrect length");
    let mut block = GenericArray::from(block);
    cipher.decrypt_block(&mut block);
    buf.extend_from_slice(&block[0..16]);
  }
  buf
}

pub fn to_hex(ba:&[u8]) -> String {
  let mut s = "".to_string();
  for b in ba {
    s += &format!("{:02X?}", b);
  }
  s
}

pub fn decode_hex(s: &str) -> Result<Vec<u8>, ParseIntError> {
    (0..s.len())
        .step_by(2)
        .map(|i| u8::from_str_radix(&s[i..i + 2], 16))
        .collect()
