add_event_listener(&id, &app, &event, &cmdlib, &cmdid);
"OK".to_string()