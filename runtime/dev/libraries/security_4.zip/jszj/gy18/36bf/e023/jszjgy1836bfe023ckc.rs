delete_user(&id);
"OK".to_string()