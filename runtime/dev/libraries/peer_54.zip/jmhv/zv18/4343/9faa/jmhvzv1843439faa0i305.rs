let mut ja = DataArray::new();
ja.push_str("reboot");
let o = system_call(ja);
o