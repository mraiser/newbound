class P2PResponse(object):
    def __init__(self, code, ba):
        self.code = code
        self.data = ba
