package com.newbound.net.service;

public class SocketClosedException extends Exception {

}
