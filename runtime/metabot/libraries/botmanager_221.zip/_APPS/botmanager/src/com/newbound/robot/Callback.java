package com.newbound.robot;

import org.json.JSONObject;

public interface Callback 
{
	public void execute(JSONObject data);
}
