package com.newbound.net.service.http;

public class Exception404 extends Exception {

	public Exception404(String string) 
	{
		super(string);
	}

}
