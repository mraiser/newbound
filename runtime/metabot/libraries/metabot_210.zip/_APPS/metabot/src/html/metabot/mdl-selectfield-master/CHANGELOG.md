<a name="1.0.4"></a>
# 1.0.4 (2016-11-05)

### New Features

* added icon on selectfield, closes [#26](https://github.com/mebibou/mdl-selectfield/issues/26)

<a name="1.0.3"></a>
# 1.0.3 (2016-11-02)

### Bug Fixes

* fix issue with "is-invalid" being removed if already present when loading component, closes [#25](https://github.com/mebibou/mdl-selectfield/issues/25)

<a name="1.0.2"></a>
# 1.0.2 (2016-06-08)

### Bug Fixes

* fix issue with wrong class name for label, closes [#19](https://github.com/mebibou/mdl-selectfield/issues/19)

<a name="1.0.1"></a>
# 1.0.1 (2016-05-02)

### Bug Fixes

* add missing dist folder, fixes [#17](https://github.com/mebibou/mdl-selectfield/issues/17)

<a name="1.0.0"></a>
# 1.0.0 (2016-04-28)

### Breaking Changes

* distribution files (compress and non-compressed) are now located under `dist` folder

### New Features

* add ability to use source scss file for custom variables (relates to [#13](https://github.com/mebibou/mdl-selectfield/issues/13) and [#16](https://github.com/mebibou/mdl-selectfield/issues/16))

<a name="0.0.3"></a>
# 0.0.3 (2015-11-24)

### Bug Fixes

* fix issue with `is-dirty` class not being added on FireFox, closes [#7](https://github.com/mebibou/mdl-selectfield/issues/7)

<a name="0.0.2"></a>
# 0.0.2 (2015-09-20)

### Bug Fixes

* added material-design-lite as a dependency

<a name="0.0.1"></a>
# 0.0.1 (2015-09-19)

Initial Release of plugin created from material design lite
