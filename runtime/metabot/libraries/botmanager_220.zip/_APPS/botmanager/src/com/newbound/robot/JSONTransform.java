package com.newbound.robot;

import org.json.JSONObject;

public interface JSONTransform 
{
	public JSONObject execute(JSONObject query);
}
