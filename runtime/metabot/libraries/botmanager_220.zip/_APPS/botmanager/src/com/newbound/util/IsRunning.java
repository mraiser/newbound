package com.newbound.util;

public interface IsRunning 
{
	public boolean isRunning();
}
