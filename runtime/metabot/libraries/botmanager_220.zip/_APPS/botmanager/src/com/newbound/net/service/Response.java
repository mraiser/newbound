package com.newbound.net.service;

public interface Response 
{
}
