package com.newbound.net.service;

public class ReleaseSocketException extends Exception {

}
