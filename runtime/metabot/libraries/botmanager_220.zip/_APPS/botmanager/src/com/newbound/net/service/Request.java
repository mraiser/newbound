package com.newbound.net.service;

import org.json.JSONObject;

public interface Request 
{
	Object getCommand();
	JSONObject getData();
}
