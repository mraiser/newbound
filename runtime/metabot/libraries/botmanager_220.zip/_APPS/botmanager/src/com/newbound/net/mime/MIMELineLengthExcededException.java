/*
 * Created on Mar 11, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.newbound.net.mime;

import java.io.IOException;

/**
 * @author mraiser
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class MIMELineLengthExcededException extends IOException
{

    /**
     * 
     */
    public MIMELineLengthExcededException()
    {
        super();
        // TODO Auto-generated constructor stub
    }

    /**
     * @param arg0
     */
    public MIMELineLengthExcededException(String arg0)
    {
        super(arg0);
        // TODO Auto-generated constructor stub
    }


}
