use flowlang::rustcmd::*;
pub struct Generated {}
impl Generated {
  pub fn init() {
    RustCmd::init();
  }
}
